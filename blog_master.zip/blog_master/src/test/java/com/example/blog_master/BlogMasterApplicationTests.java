package com.example.blog_master;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlogMasterApplicationTests {

    @Test
    void contextLoads() {
    }

}
