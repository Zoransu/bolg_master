package com.example.blog_master.service.serviceImpl;


import com.example.blog_master.mapper.BlogMapper;
import com.example.blog_master.pojo.Blog;
import com.example.blog_master.service.BlogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class BlogServiceImpl implements BlogService {

    @Autowired
    private BlogMapper blogMapper;

    @Override
    public List<Blog> getBlogsByuserId(Integer userId) {
        return blogMapper.getBlogsByuserId(userId);
    }

    @Override
    public List<Blog> getAllBlog() {
        return blogMapper.getAllBlog();
    }

    @Override
    public void postBlog(Blog blog) {
        blog.setPostTime(LocalDateTime.now());
        blogMapper.postBlog(blog);
    }

    @Override
    public void updateBlog(Blog blog) {
        blog.setPostTime(LocalDateTime.now());
        blogMapper.updateBlog(blog);
    }

    @Override
    public void deleteBlog(Integer blogId) {
        blogMapper.deleteBlogByBlogId(blogId);
    }


}
