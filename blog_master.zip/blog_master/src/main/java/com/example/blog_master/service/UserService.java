package com.example.blog_master.service;


import com.example.blog_master.pojo.Result;
import com.example.blog_master.pojo.User;

public interface UserService {

    Result addUser(User user);//新增

    User selectByName(String username); //通过用户名查找用户信息
}
