package com.example.blog_master.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Comment {
    private int userId;
    private int blogId;
    private LocalDateTime created;
    private String content;
    private String username;
}
