package com.example.blog_master.controller;


import com.example.blog_master.pojo.Blog;
import com.example.blog_master.pojo.Result;
import com.example.blog_master.pojo.User;
import com.example.blog_master.service.BlogService;
import com.example.blog_master.service.CommentService;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.annotations.Update;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDateTime;
import java.util.List;


@Slf4j
@RestController
public class BlogController {
    @Autowired
    private BlogService blogService;
    @Autowired
    private CommentService commentService;
    //删除博客
    @RequestMapping("/deleteBlog")
    public Result deleteBlog(@RequestParam Integer blogId) {
        blogService.deleteBlog(blogId);
        commentService.deleteCommentWithId(blogId);
        return Result.success();
    }

    //用户的博客
    @RequestMapping("getBlogsByuserId")
    public List<Blog> getBlogsByuserId(@RequestBody Integer userId){
       return blogService.getBlogsByuserId(userId);
    }
    //博客主页(所有博客内容)
    @RequestMapping("/face")
    public List<Blog> getAllBlog() {
        List<Blog>blogs= blogService.getAllBlog();
        for (Blog blog : blogs) {
            if(blog.getContent().length() >50 ){
                blog.setContent(blog.getContent().substring(0,50)+"....");
            }
        }
        return blogs;
    }
    //发表博客
    @PostMapping("/postBlog")
    public void postBlog(@RequestBody Blog blog){
       blogService.postBlog(blog);
    }
    //更新博客
    @PutMapping("/updateBlog")
    public void updateBlog(@RequestBody Blog blog){
        blogService.updateBlog(blog);
    }

}
