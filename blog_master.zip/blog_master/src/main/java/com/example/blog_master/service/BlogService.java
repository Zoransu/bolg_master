package com.example.blog_master.service;


import com.example.blog_master.pojo.Blog;

import java.util.List;

public interface BlogService {

    List<Blog> getBlogsByuserId(Integer userId);

    List<Blog> getAllBlog();

    void postBlog(Blog blog);

    void updateBlog(Blog blog);

    void deleteBlog(Integer blogId);
}
