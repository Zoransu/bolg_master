package com.example.blog_master.service.serviceImpl;

import com.example.blog_master.mapper.CommentMapper;
import com.example.blog_master.pojo.Comment;
import com.example.blog_master.service.CommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CommentServiceImpl implements CommentService {

    @Autowired
    private CommentMapper commentMapper;
    @Override
    public void pushComment(Comment comment) {
        commentMapper.pushComment(comment);
    }

    @Override
    public List<Comment> showCommentByBlogId(Integer blogId) {
        return commentMapper.showCommentByBlogId(blogId);
    }

    @Override
    public void deleteCommentWithId(Integer blogId) {
        commentMapper.deleteCommentWithId(blogId);
    }
}
