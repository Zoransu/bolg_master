package com.example.blog_master.controller;


import com.example.blog_master.pojo.Result;
import com.example.blog_master.pojo.User;
import com.example.blog_master.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@RestController
//登录（前端传过来的json数据）
public class LoginController {
    @Autowired
    private UserService userService;
    @RequestMapping("/login")
    public Result userLogin(@RequestBody User user, HttpServletRequest request) {
        User user1=userService.selectByName(user.getUsername());
        if(user1==null){
            return Result.error("用户名不存在，请重新登录");
        }
        else if(user1!=null && user.password.equals(user1.password)){
            HttpSession session = request.getSession(true);
            if(session!=null){
                session.setAttribute("user",user);
            }
            return Result.success();
        }else return Result.error("密码错误");

    }
}
