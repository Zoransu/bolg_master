package com.example.blog_master.mapper;


import com.example.blog_master.pojo.User;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface UserMapper {
    @Insert("insert into user (username, password)value (#{username},#{password})")
    void addUser(User user);
    @Select("select * from user where username = #{username}")
    User selectByName(String username);
}
