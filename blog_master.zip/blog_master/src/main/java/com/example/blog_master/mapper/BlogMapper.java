package com.example.blog_master.mapper;


import com.example.blog_master.pojo.Blog;
import com.example.blog_master.pojo.Result;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface BlogMapper {
    @Select(" select * from blog where userId = #{userId}")
    List<Blog> getBlogsByuserId(Integer userId);

    @Select(" select * from blog order by postTime desc")
    List<Blog> getAllBlog();

    @Select("select *from comment where blogId=#{blogId}")
    Blog getBlogByBlogId(Integer blogId);

    @Insert("insert into blog(title, content, userId) value (#{title},#{content},#{userId})")
    //@Options(useGeneratedKeys=true,keyProperty = "blogId",keyColumn = "blogId")
    void postBlog(Blog blog);

    @Delete("delete from blog where blogId=#{blogId}")
    Result deleteBlogByBlogId(Integer blogId);

    void updateBlog(Blog blog);

}
