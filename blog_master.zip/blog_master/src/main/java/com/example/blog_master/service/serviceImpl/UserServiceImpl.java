package com.example.blog_master.service.serviceImpl;


import com.example.blog_master.mapper.UserMapper;
import com.example.blog_master.pojo.Result;
import com.example.blog_master.pojo.User;
import com.example.blog_master.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserMapper userMapper;
    @Override
    //新增
    public Result addUser(User user) {
            userMapper.addUser(user);
            return Result.success();
    }

    @Override
    public User selectByName(String username) {
        return userMapper.selectByName(username);
    }

}
