package com.example.blog_master.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Blog {
    public int blogId;
    public String title;
    public String content;
    public LocalDateTime postTime;
    public int userId;
    //public int isUser;
}
