package com.example.blog_master.controller;

import com.example.blog_master.pojo.Comment;
import com.example.blog_master.pojo.Result;
import com.example.blog_master.pojo.User;
import com.example.blog_master.service.CommentService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.annotations.Select;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;
import java.util.List;

@Slf4j
@RestController
public class CommentController {

    @Autowired
    private CommentService commentService;
    //发评论
    @PostMapping("/publishComment")
    public Result publishComment(@RequestBody User user, @RequestParam Integer blogId, @RequestParam String text){
        Comment comment =new Comment();
        comment.setBlogId(blogId);
        comment.setContent(text);
        comment.setCreated(LocalDateTime.now());
        comment.setUserId(user.getUserId());
        comment.setUsername(user.getUsername());
        commentService.pushComment(comment);
        return Result.success();
    }

    // 分页展示某个博客的评论
    @RequestMapping("/showCommentByBlogId")
    public List<Comment> showCommentByBlogId( @RequestParam Integer blogId){
        return commentService.showCommentByBlogId(blogId);
    }

}
