package com.example.blog_master.controller;


import com.example.blog_master.pojo.Result;
import com.example.blog_master.pojo.User;
import com.example.blog_master.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
public class UserController {
    @Autowired
    private UserService userService;
    @PostMapping("addUser")
    public Result adduser(@RequestBody User user){
        log.info("新增用户：{}",user);
      User user1 = userService.selectByName(user.getUsername());
        if(user1==null){
            userService.addUser(user);
            return Result.success();
        }else {
            return Result.error("用户名已存在，请重新输入");
        }
    }

}
