package com.example.blog_master.mapper;

import com.example.blog_master.pojo.Comment;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface CommentMapper {
    // 分页展示某个文章的评论
    @Select("select *from comment where blogId=#{blogId} order by created desc")
    List<Comment> showCommentByBlogId(Integer blogId);
    // 发表评论
    @Insert("insert into comment(userId, blogId, created, content, username) value (#{userId},#{blogId},#{created},#{content},#{username})")
    void pushComment(Comment comment);
    //通过博客id进行删除评论
    @Delete("delete from comment where blogId=#{blogId}")
    void deleteCommentWithId(Integer blogId);

}
