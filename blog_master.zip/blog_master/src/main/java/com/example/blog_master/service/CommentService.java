package com.example.blog_master.service;

import com.example.blog_master.pojo.Comment;

import java.util.List;

public interface CommentService {
    void pushComment(Comment comment);

    List<Comment> showCommentByBlogId(Integer blogId);

    void deleteCommentWithId(Integer blogId);
}
